import Item from './Item.jsx'

function Basket(props) {
    return (
        <>
            <h1>Basket</h1>
            <h4>Number of Products in Cart: {props.cartHandlers.CountProducts(props.cart)}</h4>
            {props.cart.map((productObject, index) => {
                return( 
                    <div key={index}>
                        <Item key={index} productData={productObject.productData} />
                        <span>Count: {productObject.count}</span>
                        <button onClick={() => props.cartHandlers.DecrementProductCount(props.cart, props.cartHandlers, productObject)}>{productObject.count == 1 ? "Delete" : "Remove" }</button>
                        <button onClick={() => props.cartHandlers.IncrementProductCount(props.cart, props.cartHandlers, productObject)}>Add</button>
                    </div>
                )
            })}
        </>
    );
}

export default Basket;
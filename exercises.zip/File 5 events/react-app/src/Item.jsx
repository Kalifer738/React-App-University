function Item(props) {
    return (
        <div>
            <hr></hr>
            <p>{props.productData.id}</p>
            <p>{props.productData.name}</p>
            <p>{props.productData.price}</p>
            <img src={'/src/assets/' + props.productData.imageFileName} height={80} alt={props.productData.imageFileName} />
        </div>
    );
}

export default Item;
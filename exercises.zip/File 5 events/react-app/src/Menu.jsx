function Menu() {
    return (
        <div>
            <h1>Menu</h1>
            <div>
                <a href="/">Shop</a>
                <br/>
                <a href="/Basket">Basket</a>
            </div>
        </div>
    );
}

export default Menu;
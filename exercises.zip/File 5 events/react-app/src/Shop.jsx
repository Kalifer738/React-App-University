import { useState, useEffect } from 'react'
import Item from './Item.jsx'

//var items = new Array();

// items.push({
//     id: "123",
//     name: "My Product",
//     price: 100,
//     imageFileName: "img.png"
// });

// items.push({
//     id: "1234",
//     name: "My Product2",
//     price: 1000,
//     imageFileName: "img.png"
// });

function Shop(props) {
    let [items, setItems] = useState([]);


    useEffect(() => {
        //Both fetch APIs are valid.
        // const fetchData = async () => {
        //     const result = await fetch(`http://localhost:8000/items`);
        //     result.json().then(object => setItems(object));
        // }
        // fetchData();
        
        fetch('http://localhost:8000/items/')
        .then(response => response.json())
        .then(object => {
            setItems(object);
        })
        .catch(error => console.error('API Error!', error));
    }, []);

    return (
        <div>
            <h1>Shop</h1>
            <h4>Number of Products in Cart: {props.cartHandlers.CountProducts(props.cart)}</h4>
            {items.map((productObject, index) => {
                return (
                    <div key={index}>
                        <Item productData={productObject} />
                        <button onClick={() => props.cartHandlers.AddProductOrIncrementCount(props.cart, props.cartHandlers, {productData: productObject, count: 1})}>
                            Add to Cart
                        </button>
                    </div>
                )
            })}
        </div>
    );
}

export default Shop;
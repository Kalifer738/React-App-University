import { useState, useEffect } from 'react'
import Shop from './Shop.jsx'
import Basket from './Basket.jsx'
import Menu from './Menu.jsx'

import { BrowserRouter, Routes, Route } from "react-router-dom";

/*

TO RUN THIS PROJECT, YOU NEED TO RUN JSON SERVER ALONGSIDE THIS PROJECT!!!

npx json-server --watch .\src\restful\restful.json --port 8000 

*/

function App() {
  // Initialize cart from sessionStorage or default to an empty array.
  let [cart, setCart] = useState(() => {
    var products = sessionStorage.getItem('cart');

    if (products) {
      products = JSON.parse(sessionStorage.getItem('cart'));
    }
    else {
      products = [];
    }
    
    return products;
  });

  useEffect(() => {
    sessionStorage.setItem('cart', JSON.stringify(cart));
  });

  //Store all of the CRUD functions in an object, and pass it down to the objects who might need to manipulate the cart.
  var cartHandlersFuncs = {};
  cartHandlersFuncs.CountProducts = countProducts;
  cartHandlersFuncs.AddProductOrIncrementCount = addProductOrIncrementCount;
  cartHandlersFuncs.UpdateProductCount = updateProductCount;
  cartHandlersFuncs.IncrementProductCount = incrementProductCount;
  cartHandlersFuncs.DecrementProductCount = decrementProductCount;
  cartHandlersFuncs.UpdateProduct = updateProduct;
  cartHandlersFuncs.AddProduct = addProduct;
  cartHandlersFuncs.RemoveProduct = removeProduct;
  cartHandlersFuncs.SetCart = setCart;

  return (
    <>
      <Menu />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Shop cart={cart} cartHandlers={cartHandlersFuncs} />} />
          <Route path="/Basket" element={<Basket cart={cart} cartHandlers={cartHandlersFuncs} />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

function addProductOrIncrementCount(cart, cartHandlers, productObject) {
  for (let index = 0; index < cart.length; index++) {
    const id = cart[index].productData.id;
    if (id == productObject.productData.id) {
      const products = cart.slice();
      products[index].count++;
      cartHandlers.SetCart(products);
      return;
    }
  }

  addProduct(cart, cartHandlers, productObject);
}

function incrementProductCount(cart, cartHandlers, productObject) {
  cartHandlers.UpdateProductCount(cart, cartHandlers, productObject, productObject.count + 1);
}

function decrementProductCount(cart, cartHandlers, productObject) {
  if (productObject.count - 1 <= 0) {
    removeProduct(cart, cartHandlers, productObject);
    return;
  }
  
  cartHandlers.UpdateProductCount(cart, cartHandlers, productObject, productObject.count - 1);
}

function updateProductCount(cart, cartHandlers, productObject, count) {
  for (let index = 0; index < cart.length; index++) {
    if (cart[index].productData.id == productObject.productData.id) {
      const products = cart.slice();
      products[index].count = count;
      cartHandlers.SetCart(products);
      return;
    }
  }
}

function updateProduct(cart, cartHandlers, productObject) {
  for (let index = 0; index < products.length; index++) {
    if (cart[index].productData.id == productObject.productData.id) {
      const products = cart.slice();
      products[index] = productObject;
      cartHandlers.SetCart(products);
      return true;
    }
  }

  return false;
}

function addProduct(cart, cartHandlers, productObject) {
  cartHandlers.SetCart([...cart, productObject]);
}

function removeProduct(cart, cartHandlers, productObject) {
  cartHandlers.SetCart(c => c.filter((element) => element.productData.id != productObject.productData.id));
}

function countProducts(cart) {
  return cart.reduce((total, product) => total + product.count, 0);
}

export default App;
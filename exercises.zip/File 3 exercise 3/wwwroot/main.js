const personNameInput = document.getElementById("personName");
const personBirthday = document.getElementById("personBirthday");
const personMajor = document.getElementById("personMajor");
const personSSN = document.getElementById("personSSN");
const personSalary = document.getElementById("personSalary");

const radioStudent = document.getElementById("radioStudent");
const radioEmployee = document.getElementById("radioEmployee");
const display = document.getElementById('employeeData');

document.getElementById("addPersonButton").addEventListener("click", addPerson);
document.getElementById('fetchData').addEventListener('click', fetchData);
document.getElementById('showOnlyStudents').addEventListener('click', filterOnlyStudents);
document.getElementById('showOnlyEmployees').addEventListener('click', filterOnlyEmployees);
document.getElementById('showPeople').addEventListener('click', showPeople);

var peopleArray = new Array();

function filterOnlyEmployees() {
    displayPeopleArray(peopleArray.filter(person => person instanceof Employee));
}

function filterOnlyStudents() {
    displayPeopleArray(peopleArray.filter(person => person instanceof Student));
}

function showPeople() {
    displayPeopleArray(peopleArray);
}

function addPerson() {
    if (radioEmployee.checked) {
        peopleArray.push(new Employee(personNameInput.value, personBirthday.value, personSSN.value, personSalary.value));
    }
    else if (radioStudent.checked) {
        peopleArray.push(new Student(personNameInput.value, personBirthday.value, personMajor.value));
    }
    displayPeopleArray(peopleArray);
}

function displayPeopleArray(peopleArray) {
    display.innerHTML = '';
    peopleArray.forEach(person => {
        const personElement = document.createElement('span');
        const br = document.createElement('br');
        personElement.textContent = person.toString();
        display.appendChild(personElement);
        display.appendChild(br);
    });
}

function fetchData() {
    fetch('/api/data.json')
        .then(response => response.json())
        .then(data => {
            data.forEach(person => {
                if (person.type === 'student') {
                    peopleArray.push(new Student(person.name, person.birthDate, person.majorDept));
                }
                else if (person.type === 'employee') {
                    peopleArray.push(new Employee(person.name, person.birthDate, person.majorDept, person.salary));
                }
            });
            displayPeopleArray(peopleArray);
        })
        .catch(error => console.error('Error: ', error));
}

class Person {
    constructor(name, birthDate) {
        this.name = name;
        this.birthDate = birthDate;
    }

    getName() {
        return this.name;
    }

    getType() {
        return "Person";
    }

    toString() {
        return `${this.getType()}: Name:${this.name} Birthday:${this.birthDate}`;
    }
}

class Employee extends Person {
    constructor(name, birthDate, ssn, salary) {
        super(name, birthDate);
        this.ssn = ssn;
        this.salary = salary;
    }

    getType() {
        return "Employee";
    }

    toString() {
        return `${super.toString()}, SSN:${this.ssn}, Salary:${this.salary}`;
    }

    getSSN() {
        return this.ssn;
    }

    getSalary() {
        return this.salary;
    }
}

class Student extends Person {
    constructor(name, birthDate, majorDpt) {
        super(name, birthDate);
        this.majorDpt = majorDpt;
    }

    getType() {
        return "Student";
    }

    toString() {
        return `${super.toString()}, Major Department:${this.majorDpt}`;
    }

    getMajorDpt() {
        return this.majorDpt;
    }
}

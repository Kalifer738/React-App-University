//https://www.freecodecamp.org/news/how-to-create-a-react-app-with-a-node-backend-the-complete-guide/

const PORT = process.env.PORT || 3000;
const express = require('express');
const fs = require('node:fs');
const app = express();



app.get('/', (req, res) => {
    res.sendFile(`${__dirname}\\wwwroot\\index.html`);
});

app.get("/api/*", (req, res) => {
    var path = `${__dirname}\\wwwapi${req.path}`;
    path = path.replace('/api', '');
    path = path.replace(/\/+/g, '\\');

    // Return an 403 error 'Forbidden' if the request contains 2 dots (To make sure it doesn't try to escape to a different backwords path.)
    if (path.indexOf('..') > 0) {
        return res.status(403).send('Forbidden');
    }

    fs.readFile(path, 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(404).send('Internal Server Error');
        }
        res.json(JSON.parse(data));
    });
});

app.get('*', (req, res) => {
    var path = `${__dirname}\\wwwroot${req.path}`;
    path = path.replace(/\/+/g, '\\');

    // Return an 403 error 'Forbidden' if the request contains 2 dots (To make sure it doesn't try to escape to a different backwords path.)
    if (path.indexOf('..') > 0) {
        return res.status(403).send('Forbidden');
    }

    res.sendFile(path);
});

app.listen(PORT, () => {
    console.log(`Server listening on ${PORT}`);
});
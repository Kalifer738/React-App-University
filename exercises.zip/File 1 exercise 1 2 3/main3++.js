const mainInput = document.getElementById("mainInput");
const display = document.getElementById("display");
const defaultDisplayElementIndex = document.createElement("span");
const defaultDisplayElementValue = document.createElement("input");
const defaultDisplayElementEditValueButton = document.createElement("button");
const defaultDisplayContainer = document.createElement("div");

var g_Array = new Array();

document.getElementById("pushElement").addEventListener("click", pushElement);
document.getElementById("popElement").addEventListener("click", popElement);
defaultDisplayElementEditValueButton.addEventListener("click", (element) => {
    swapIndexies(element.getAttribute("index"), element.getAttribute("value"));
});

defaultDisplayElementValue.type = "text";
defaultDisplayElementValue.textContent = "Modify";



defaultDisplayContainer.appendChild(defaultDisplayElementIndex);
defaultDisplayContainer.appendChild(defaultDisplayElementValue);
defaultDisplayContainer.appendChild(defaultDisplayElementEditValueButton);


function pushElement() {
    if (mainInput.value == "") {
        return;
    }
    g_Array.push(mainInput.value);
    mainInput.value = "";
    updateDisplay();
}

function popElement() {
    if (g_Array.length > 0) {
        g_Array.pop();
    }
    updateDisplay();
}

function swapIndexies(index1, index2) {
    if ((index1 < 0 || index1 > g_Array.length - 1) || (index2 < 0 || index2 > g_Array.length - 1)) {
        return;
    }
    const temp = g_Array[index1];
    g_Array[index1] = g_Array[index2];
    g_Array[index2] = temp;
    updateDisplay();
}

function updateDisplay() {
    // Remove the uneceserry children.
    if (display.children.length > g_Array.length) {
        for (let index = 0; index < display.children.length - g_Array.length; index++) {
            display.removeChild(display.lastChild);
        }
    }
    // Or add in the neceserry children.
    else {
        for (let index = 0; index < g_Array.length - display.children.length; index++) {
            var newElement = defaultDisplayContainer.cloneNode(true);
            var newDisplayButton = newElement.children[2];
            newDisplayButton.addEventListener("click", (event) => {
                const index = event.target.getAttribute("index");
                const value = event.target.parentElement.children[1].value;
                swapIndexies(index, value);
            });
            display.appendChild(newElement);
        }
    }


    for (let index = 0; index < display.children.length; index++) {
        var div = display.children[index];
        var newDisplayIndex = div.children[0];
        var newDisplayValue = div.children[1];
        var newDisplayButton = div.children[2];

        newDisplayIndex.textContent = `Value: ${g_Array[index]}`;
        newDisplayValue.value = index;
        newDisplayButton.setAttribute("index", index);
        newDisplayButton.textContent = "Change Index";
    }
}
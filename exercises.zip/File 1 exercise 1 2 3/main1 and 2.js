const input1 = document.getElementById("num1");
const input2 = document.getElementById("num2");
const output = document.getElementById("result");

document.getElementById("sum").addEventListener("click", sumFunc);
document.getElementById("difference").addEventListener("click", differenceFunc);
document.getElementById("multiplication").addEventListener("click", multiplicationFunc);
document.getElementById("devision").addEventListener("click", devisionFunc);

function sumFunc(){
    let result = parseFloat(input1.value) + parseFloat(input2.value);
    if (Object.is(result, NaN)) {
        output.value = "";
        return;
    }
    output.value = result;
}

function differenceFunc() {
    let result = parseFloat(input1.value) - parseFloat(input2.value);
    if (Object.is(result, NaN)) {
        output.value = "";
        return;
    }
    output.value = result;
}

function multiplicationFunc() {
    let result = parseFloat(input1.value) * parseFloat(input2.value);
    if (Object.is(result, NaN)) {
        output.value = "";
        return;
    }
    output.value = result;
}

function devisionFunc() {
    let result = parseFloat(input1.value) / parseFloat(input2.value);
    if (Object.is(result, NaN)) {
        output.value = "";
        return;
    }
    output.value = result;
}
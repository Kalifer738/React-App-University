import { LetterPassword, NumericPassword } from "/modules/BaseSymbol.js";

function generatePassword(passwordType, passwordLength) {
    var stringPassword = "";
    var allowedSymbols = "";

    if (passwordType === 'LetterPassword') {
        allowedSymbols = 'aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ';
    }
    else if (passwordType === 'NumericPassword') {
        allowedSymbols = '0123456789';
    }
    else {
        throw new Error('Invalid password type');
    }

    for (let i = 0; i < passwordLength; i++) {
        stringPassword += allowedSymbols.charAt(Math.floor(Math.random() * allowedSymbols.length));
    }

    if (passwordType === 'LetterPassword') {
        return new LetterPassword(stringPassword);    
    }
    else {
        return new NumericPassword(stringPassword);
    }
}

function passwordStrength(password) {
    if (password.length() < 5) {
        return 0;
    }
    if (password.length() <= 10) {
        return 1;
    }
    if (password.length() > 10) {
        return 2;
    }
}

export { generatePassword, passwordStrength };
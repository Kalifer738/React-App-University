class BaseSymbol {
    constructor(symbol) {
        if (typeof symbol !== 'string' /*|| !(symbol instanceof String)*/) {
            throw new Error("Invalid Type! Expected string, but got " + typeof symbol);
        }
        this.m_Symbol = symbol;
    }

    toUpper() {
        this.m_Symbol = this.m_Symbol.toUpperCase();
    }

    toLower() {
        this.m_Symbol = this.m_Symbol.toLowerCase();
    }

    print() {
        console.log(this.m_Symbol);
    }

    getType() {
        return "BaseSymbol";
    }
}

class Digit extends BaseSymbol {
    constructor(digit) {
        super(digit);
        if (!/^\d+$/.test(digit)) {
            throw new Error(`Invalid input! Expected digit, but got ${digit}`);
        }
    }
    getType() {
        return "Digit";
    }
}

class Letter extends BaseSymbol {
    constructor(letter) {
        super(letter);
        if (!/^[a-zA-Z]+$/.test(letter)) {
            throw new Error(`Invalid input! Expected letter, but got ${letter}`);
        }
    }
    getType() {
        return "Letter";
    }
}

class NumericPassword {
    constructor(stringPassword) {
        this.m_Array = new Array();
        for (var i = 0; i < stringPassword.length; i++)
        {
            this.m_Array.push(new Digit(stringPassword[i]));
        }
    }

    getType() {
        return "NimeicPassword";
    }

    print() {
        console.log(this.toString());
    }

    toString() {
        var outputString = "";
        for (let i = 0; i < this.m_Array.length; i++) {
            outputString += this.m_Array[i].m_Symbol;
        }

        return outputString;
    }

    setPassword(password) {
        if (typeof password !== 'string' || !(password instanceof String)) {
            throw new Error("Invalid Type! Expected string, but got " + typeof password);
        }

        for (let i = 0; i < password.length; i++) {
            this.m_Array.push(new Digit(password[i]));
        }
    }
    length() {
        return this.m_Array.length;
    }
}

class LetterPassword {
    constructor(stringPassword) {
        this.m_Array = new Array();
        for (var i = 0; i < stringPassword.length; i++) {
            this.m_Array.push(new Letter(stringPassword[i]));
        }
    }

    getType() {
        return "LetterPassword";
    }

    print() {
        console.log(this.toString());
    }

    toString() {
        var outputString = "";
        for (let i = 0; i < this.m_Array.length; i++) {
            outputString += this.m_Array[i].m_Symbol;
        }
        return outputString;
    }

    setPassword(password) {
        if (typeof password !== 'string' || !(password instanceof String)) {
            throw new Error("Invalid Type! Expected string, but got " + typeof password);
        }

        for (let i = 0; i < password.length; i++) {
            this.m_Array.push(new Letter(password[i]));
        }
    }

    length() {
        return this.m_Array.length;
    }
}

export { BaseSymbol, Digit, NumericPassword, LetterPassword };
// BaseSymbol.js
class BaseSymbol {
    constructor(symbol) {
        this.symbol = symbol;
    }

    toUpper() {
        this.symbol = this.symbol.toUpperCase();
    }

    toLower() {
        this.symbol = this.symbol.toLowerCase();
    }

    print() {
        console.log(this.symbol);
    }

    getType() {
        return "BaseSymbol";
    }
}

module.exports = BaseSymbol;

// Digit.js
const BaseSymbol = require('./BaseSymbol');

class Digit extends BaseSymbol {
    getType() {
        return "Digit";
    }
}

module.exports = Digit;

// Letter.js
const BaseSymbol = require('./BaseSymbol');

class Letter extends BaseSymbol {
    getType() {
        return "Letter";
    }
}

module.exports = Letter;

// NumericPassword.js
const Digit = require('./Digit');

class NumericPassword {
    constructor() {
        this.passwordArray = [];
    }

    setPassword(password) {
        this.passwordArray = password.split('').map(char => new Digit(char));
    }

    print() {
        this.passwordArray.forEach(digit => digit.print());
    }

    getType() {
        return "NumericPassword";
    }

    toString() {
        return this.passwordArray.map(digit => digit.symbol).join('');
    }
}

module.exports = NumericPassword;

// LetterPassword.js
const Letter = require('./Letter');

class LetterPassword {
    constructor() {
        this.passwordArray = [];
    }

    setPassword(password) {
        this.passwordArray = password.split('').map(char => new Letter(char));
    }

    print() {
        this.passwordArray.forEach(letter => letter.print());
    }

    getType() {
        return "LetterPassword";
    }

    toString() {
        return this.passwordArray.map(letter => letter.symbol).join('');
    }
}

module.exports = LetterPassword;

// passwordTools.js
const NumericPassword = require('./NumericPassword');
const LetterPassword = require('./LetterPassword');

function generatePassword(length, isNumeric) {
    const chars = isNumeric ? '0123456789' : 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let password = '';
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    if (isNumeric) {
        const numericPassword = new NumericPassword();
        numericPassword.setPassword(password);
        return numericPassword;
    } else {
        const letterPassword = new LetterPassword();
        letterPassword.setPassword(password);
        return letterPassword;
    }
}

function passwordStrength(password) {
    const length = password.length;
    if (length < 5) {
        return 0;
    } else if (length <= 10) {
        return 1;
    } else {
        return 2;
    }
}

module.exports = { generatePassword, passwordStrength };
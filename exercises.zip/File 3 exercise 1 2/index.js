//https://www.freecodecamp.org/news/how-to-create-a-react-app-with-a-node-backend-the-complete-guide/

const PORT = process.env.PORT || 3000;
const express = require('express');
const app = express();



app.get('/', (req, res) => {
    res.sendFile(`${__dirname}\\wwwroot/index.html`);
});

app.get('*', (req, res) => {
    var path = `${__dirname}\\wwwroot${req.path}`;
    
    // Return an 403 error 'Forbidden' if the request contains 2 dots (To make sure it doesn't try to escape to a different backwords path.)
    if(path.indexOf('..') > 0) {
        return res.status(403).send('Forbidden');
    }
    
    res.sendFile(path);
});



app.get("/api", (req, res) => {
    res.json({ message: "Hello from server!" });
});

app.listen(PORT, () => {
    console.log(`Server listening on ${PORT}`);
});
import imgTodo from './assets/imgTodo.png';
import imgDone from './assets/imgDone.png';

function Tasks(props) {
    return (
        <div>
            <h1>{props.title}</h1>
            {console.log(props)}

            <ul>
                {props.tasks.tasks.map((task, index) => (
                    <div>
                        <li key={index}>{task.title}</li>
                        <img src={task.completed ? imgDone : imgTodo} height={20} alt={task.completed ? "Task completed" : "Task not completed"} />
                    </div>
                ))}
            </ul>
        </div>
    );
}

export default Tasks
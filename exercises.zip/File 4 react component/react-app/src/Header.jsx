import './Header.css'

function Header() {
    return "My App";
}

export default Header;
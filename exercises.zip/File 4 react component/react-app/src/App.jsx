import './App.css'
import Tasks from './Tasks.jsx'

var todoTasks = {
  title: "Todo Tasks",
  tasks:
    [
      { title: "TaskOne", completed: false },
      { title: "TaskTwo", completed: false },
      { title: "TaskThree", completed: false }
    ]
};
var completedTasks = {
  title: "Completed Tasks",
  tasks:
    [
      { title: "TaskFour", completed: true },
      { title: "TaskFive", completed: true },
      { title: "TaskSix", completed: true }
    ]
}

function App() {
  return (
    <>
      <div>
        <Tasks tasks={todoTasks} title="Задачи за изпълнение" />
        <Tasks tasks={completedTasks} title="Завършени задачи"/>
      </div>
    </>
  )
}

export default App
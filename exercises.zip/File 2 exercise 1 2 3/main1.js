const personNameInput = document.getElementById("personName");
const radioStudent = document.getElementById("radioStudent");
const radioEmployee = document.getElementById("radioEmployee");
const addPersonButton = document.getElementById("addPersonButton");
const namePercentButton = document.getElementById("showNamePercentButton");

addPersonButton.addEventListener("click", addPerson);
namePercentButton.addEventListener("click", printNamesAveragePercent);

var peopleArray = new Array();

function addPerson() {
    if (radioEmployee.checked) {
        peopleArray.push(new Employee(personNameInput.value, null, null, null));
    }
    else if (radioStudent.checked) {
        peopleArray.push(new Student(personNameInput.value, null, null));
    }
}


function printNamesAveragePercent() {
    // Print "Empty array" if the peopleArray is empty.
    if(peopleArray.length === 0) {
        console.log("Empty array");
        return;
    }

    // Create a Map with names as keys and the number of occurrences as values.
    var peopleNamesMap = new Map();
    for (let index = 0; index < peopleArray.length; index++) {
        const element = peopleArray[index];
        if(peopleNamesMap.has(element.name)) {
            peopleNamesMap.set(element.name, peopleNamesMap.get(element.name) + 1);
        }
        else {
            peopleNamesMap.set(element.name, 1);
        }
    }

    // Iterate through people map and print the value stored in peopleNamesMap, after being devided by the number of peopleArray elements.
    for (let [name, count] of peopleNamesMap) {
        console.log(`${name}: ${(count / peopleArray.length) * 100}%`);
    }
}



class Person {
    constructor(name) {
        this.name = name;
    }

    getName() {
        return this.name;
    }
}

class Employee extends Person {
    constructor(name, birthDate, ssn, salary) {
        super(name, birthDate);
        this.ssn = ssn;
        this.salary = salary;
    }

    getSSN() {
        return this.ssn;
    }

    getSalary() {
        return this.salary;
    }
}

class Student extends Person {
    constructor(name, birthDate, majorDpt) {
        super(name, birthDate);
        this.majorDpt = majorDpt;
    }

    getMajorDpt() {
        return this.majorDpt;
    }
}

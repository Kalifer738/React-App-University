/* Създайте функция-конструктор, която създава обекти от тип фигура (Figure). Функцията трябва да приема променлива от тип string (която може да бъде: квадрат, кръг и правоъгълник) и две целочислени променливи.
В зависимост от типа на фигурата, първата променлива може да бъде: страна на квадрат или правоъгълник или радиус на кръг. Втората страна може да съдържа втората страна на правоъгълника.
След като създадете функцията конструктор, създайте JavaScript код, който да генерира 100 двойки произволни фигури като ползва Math.random() (виж: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random). Нека всеки път, когато двойката фигури е от един и същ тип да се отпечатват двата обекта в конзолата.
За да проверите дали двете фигури са еднакви, използвайте някой от посочените в лекцията варианти. */

const generateFigures = document.getElementById("generateFigures");
generateFigures.addEventListener("click", generateRandomFigures);

function generateRandomFigures() {
    const figures = [];
    let samePairCount = 0;

    for (let i = 0; i < 100; i++) {
        const randomType1 = getRandomType();
        const randomSide11 = getRandomSide();
        const randomSide21 = getRandomSide();
        
        const randomType2 = getRandomType();
        const randomSide12 = getRandomSide();
        const randomSide22 = getRandomSide();
        
        const figure1 = createFigure(randomType1, randomSide11, randomSide21);
        const figure2 = createFigure(randomType2, randomSide12, randomSide22);

        figures.push(figure1);
        figures.push(figure2);

        if(randomType1 === randomType2) {
            printFigure(figure1);   
            printFigure(figure2);    
            samePairCount++;
        }

    }

    console.log(`Same pair count: ${samePairCount}`);
    return figures;
}

function printFigure(figure) {
    console.log(`Figure: ${figure.type}`);
    console.log(`Area: ${figure.getArea()}`);
    console.log(`Perimeter: ${figure.getPerimeter()}`);
}

function getRandomType() {
    const types = ["square", "rectangle", "circle"];
    return types[Math.floor(Math.random() * types.length)];
}

function getRandomSide() {
    return Math.floor(Math.random() * 100) + 1;
}


function createFigure(type, side1, side2) {
    switch (type) {
        case "square":
            return new Square(side1);
        case "rectangle":
            return new Rectangle(side1, side2);
        case "circle":
            return new Circle(side1);
        default:
            throw new Error("Invalid figure type");
    }
}

class Figure {
    constructor(type) {
        this.type = type;
    }

    getArea() {
        throw new Error("Subclasses must implement getArea method!");
    }

    getPerimeter() {
        throw new Error("Subclasses must implement getPerimeter method!");
    }
}

class Square extends Figure {
    constructor(side1) {
        super("square");
        this.side1 = side1;
    }
    getArea() {
        return this.side1 * this.side1;
    }
    getPerimeter() {
        return 4 * this.side1;
    }
}

class Rectangle extends Figure {
    constructor(side1, side2) {
        super("rectangle");
        this.side1 = side1;
        this.side2 = side2;
    }
    getArea() {
        return this.side1 * this.side2;
    }
    getPerimeter() {
        return 2 * (this.side1 + this.side2);
    }
}

class Circle extends Figure {
    constructor(radius) {
        super("circle");
        this.radius = radius;
    }
    getArea() {
        return Math.PI * Math.pow(this.radius, 2);
    }
    getPerimeter() {
        return 2 * Math.PI * this.radius;
    }
}